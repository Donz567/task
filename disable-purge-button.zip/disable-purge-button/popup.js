document.getElementById("apply").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const selector = document.getElementById("selector").value.trim();
  const action = document.getElementById("action").value;

  if (!selector) {
    document.getElementById("status").textContent = "⚠️ Please enter a CSS selector.";
    return;
  }

  // Save settings for this domain
  const url = new URL(tab.url);
  const domain = url.hostname;

  chrome.storage.sync.set({ [domain]: { selector, action } }, () => {
    document.getElementById("status").textContent = `✅ Applied on ${domain}`;
  });
});

document.getElementById("clear").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = new URL(tab.url);
  const domain = url.hostname;

  chrome.storage.sync.remove(domain, () => {
    document.getElementById("status").textContent = `❌ Cleared for ${domain}`;
  });
});
