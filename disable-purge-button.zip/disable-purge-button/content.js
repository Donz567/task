const applyRules = () => {
  const domain = window.location.hostname;

  chrome.storage.sync.get(domain, (data) => {
    if (!data[domain]) return;
    const { selector, action } = data[domain];
    const elements = document.querySelectorAll(selector);

    elements.forEach(el => {
      if (action === "hide") {
        el.style.display = "none";
      } else if (action === "disable") {
        el.style.pointerEvents = "none";
        el.style.opacity = "0.5";
        el.style.filter = "grayscale(100%)";
        el.style.textDecoration = "line-through";
        el.title = "Disabled by Element Disabler extension";
      }
    });
  });
};

// Run on page load
document.addEventListener("DOMContentLoaded", applyRules);

// Watch dynamically added elements
const observer = new MutationObserver(applyRules);
observer.observe(document.body, { childList: true, subtree: true });
