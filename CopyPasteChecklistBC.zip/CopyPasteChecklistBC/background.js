chrome.action.onClicked.addListener(() => {
 
  const width = 250;
  const height = 500;


  chrome.system.display.getInfo((displays) => {
    const primaryDisplay = displays[0].workArea; 
    const screenWidth = primaryDisplay.width;
    const screenHeight = primaryDisplay.height;

    
    const offsetX = 90; // distance from right edge
    const offsetY = 80; // distance from top edge

    const left = screenWidth - width - offsetX;
    const top = offsetY;

    chrome.windows.create({
      url: "popup.html",
      type: "popup",
      width: width,
      height: height,
      left: left,
      top: top
    });
  });
});
