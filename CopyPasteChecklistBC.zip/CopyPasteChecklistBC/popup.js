const fields = [
  "Title","Color","Size","Product Type","Variation","Gender",
  "Image","Bullets","Description","Keywords","Browse Path",
  "Brand Name","Reviews","W+D","Multiple Product ID"
];

const tbody = document.getElementById("fields");


const savedDefaults = JSON.parse(localStorage.getItem("checklistDefaults")) || {};


fields.forEach(field => {
  if (!savedDefaults[field]) savedDefaults[field] = "❌";
});


fields.forEach(field => {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td class="field">${field}</td>
    <td><input type="radio" name="${field}" value="❌" ${savedDefaults[field]==="❌" ? "checked" : ""}></td>
    <td><input type="radio" name="${field}" value="✔️" ${savedDefaults[field]==="✔️" ? "checked" : ""}></td>
    <td><input type="radio" name="${field}" value="🚫" ${savedDefaults[field]==="🚫" ? "checked" : ""}></td>
  `;
  tbody.appendChild(tr);
});


let isDragging = false;
tbody.addEventListener("mousedown", e => {
  if (e.target.type === "radio") {
    isDragging = true;
    e.target.checked = true;
  }
});
tbody.addEventListener("mousemove", e => {
  if (!isDragging) return;
  if (e.target.type === "radio") e.target.checked = true;
});
document.addEventListener("mouseup", () => isDragging = false);


function buildOutput() {
  let output = "";
  fields.forEach(field => {
    const checked = document.querySelector(`input[name="${field}"]:checked`);
    const val = checked ? checked.value : "❌";
    output += `${val}${field}\n`;
  });
  return output;
}


function saveDefaults() {
  const current = {};
  fields.forEach(field => {
    const checked = document.querySelector(`input[name="${field}"]:checked`);
    current[field] = checked ? checked.value : "❌";
  });
  localStorage.setItem("checklistDefaults", JSON.stringify(current));
}


function showMessage(msg) {
  const div = document.createElement("div");
  div.textContent = msg;
  div.style.position = "fixed";
  div.style.top = "6px";
  div.style.left = "50%";
  div.style.transform = "translateX(-50%)";
  div.style.background = "#4CAF50";
  div.style.color = "#fff";
  div.style.padding = "4px 8px";
  div.style.fontSize = "11px";
  div.style.borderRadius = "3px";
  div.style.zIndex = "9999";
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 1000);
}


document.getElementById("copy").addEventListener("click", async () => {
  const output = buildOutput();
  await navigator.clipboard.writeText(output);
  saveDefaults();
  showMessage("✅ Copied and saved!");
  setTimeout(() => window.close(), 1000); // ✅ Close popup after 1 second
});


document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === "c") {
    e.preventDefault();
    document.getElementById("copy").click();
  }
});
