(async function () {
  // --- 1. UI Overlay ---
  const docHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
  const docWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);

  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'absolute', top: '0', left: '0',
    width: docWidth + 'px', height: docHeight + 'px',
    background: 'rgba(0,0,0,0.2)', // Darker tint for better selection visibility
    cursor: 'crosshair', zIndex: '2147483647'
  });
  document.body.appendChild(overlay);

  const box = document.createElement('div');
  Object.assign(box.style, {
    position: 'absolute', 
    border: '2px dashed #ff0000',
    background: 'rgba(255, 0, 0, 0.1)',
    display: 'none',
    pointerEvents: 'none'
  });
  overlay.appendChild(box);

  const msg = document.createElement('div');
  msg.innerText = "Select area. I will capture original colors (no tint) & fix lines.";
  Object.assign(msg.style, {
    position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
    background: '#222', color: '#fff', padding: '10px 20px', borderRadius: '4px',
    fontFamily: 'sans-serif', zIndex: '2147483648', pointerEvents: 'none'
  });
  document.body.appendChild(msg);

  // --- 2. Selection Logic ---
  let startX, startY, isSelecting = false;

  overlay.onmousedown = (e) => {
    isSelecting = true;
    startX = e.pageX; 
    startY = e.pageY;
    box.style.display = 'block';
    updateBox(e.pageX, e.pageY);
  };

  overlay.onmousemove = (e) => {
    if (!isSelecting) return;
    updateBox(e.pageX, e.pageY);
  };

  function updateBox(currentX, currentY) {
    const left = Math.min(startX, currentX);
    const top = Math.min(startY, currentY);
    const width = Math.abs(currentX - startX);
    const height = Math.abs(currentY - startY);
    Object.assign(box.style, { left: left + 'px', top: top + 'px', width: width + 'px', height: height + 'px' });
  }

  overlay.onmouseup = async () => {
    if (!isSelecting) return;
    isSelecting = false;
    
    const rect = {
        left: parseInt(box.style.left),
        top: parseInt(box.style.top),
        width: parseInt(box.style.width),
        height: parseInt(box.style.height)
    };

    if (rect.width < 10 || rect.height < 10) return;

    overlay.style.pointerEvents = 'none';
    msg.innerText = "Capturing... (Overlay hidden for true color)";
    
    await captureTrueColor(rect);
  };

  // --- 3. Capture Logic ---
  async function captureTrueColor(rect) {
    const images = [];
    const viewportHeight = window.innerHeight;
    const dpr = window.devicePixelRatio || 1;
    
    let capturedHeightCss = 0;
    
    // Setup environment
    const originalScroll = document.documentElement.style.scrollBehavior;
    const originalOverflow = document.body.style.overflow;
    document.documentElement.style.scrollBehavior = 'auto';
    document.body.style.overflow = 'hidden'; 

    const sleep = ms => new Promise(r => setTimeout(r, ms));

    try {
      // KEY FIX: Hide the ENTIRE overlay (grey tint), not just the box
      overlay.style.opacity = '0'; 
      // We keep it in DOM but invisible so we don't break logic, or we can just hide it:
      overlay.style.display = 'none';
      if(msg) msg.style.display = 'none'; // Hide message too

      while (capturedHeightCss < rect.height) {
        
        // Scroll
        const targetScrollY = rect.top + capturedHeightCss;
        window.scrollTo(window.scrollX, targetScrollY);
        await sleep(600); 

        // Hide Sticky Headers
        const fixedElements = hideFixedElements();
        await sleep(50); 

        // Capture (Now the screen is clean, no grey tint)
        const dataUrl = await sendMessageToBackground({ type: 'CAPTURE' });

        // Restore Headers
        restoreFixedElements(fixedElements);

        // Calculate Crop
        const remainingCss = rect.height - capturedHeightCss;
        const segmentHeightCss = Math.min(viewportHeight, remainingCss);

        const imgX = Math.round((rect.left - window.scrollX) * dpr);
        const imgY = 0; 
        const imgW = Math.round(rect.width * dpr);
        const imgH = Math.round(segmentHeightCss * dpr);

        images.push({
            src: dataUrl,
            x: imgX, y: imgY, w: imgW, h: imgH
        });

        capturedHeightCss += segmentHeightCss;
      }

    } catch (err) {
      console.error(err);
      alert("Error: " + err.message);
    } finally {
      // Restore everything
      document.documentElement.style.scrollBehavior = originalScroll;
      document.body.style.overflow = originalOverflow;
      if(overlay.parentNode) document.body.removeChild(overlay);
      if(msg.parentNode) document.body.removeChild(msg);
    }

    await stitchImagesWithOverlap(images, Math.round(rect.width * dpr), Math.round(rect.height * dpr));
  }

  // --- 4. Helpers ---
  function hideFixedElements() {
    const hidden = [];
    const all = document.querySelectorAll('*');
    for (const el of all) {
        const style = window.getComputedStyle(el);
        if (style.position === 'fixed' || style.position === 'sticky') {
            if (style.visibility !== 'hidden' && el.offsetHeight > 0) {
                 hidden.push({ el: el, visibility: el.style.visibility });
                 el.style.visibility = 'hidden'; 
            }
        }
    }
    return hidden;
  }

  function restoreFixedElements(hiddenList) {
    for (const item of hiddenList) {
        item.el.style.visibility = item.visibility;
    }
  }

  function sendMessageToBackground(payload) {
    return new Promise((resolve) => {
      if (!chrome.runtime?.id) return resolve(null);
      chrome.runtime.sendMessage(payload, (res) => resolve(res?.image || null));
    });
  }

  // --- 5. Stitching (Overlap + Filename) ---
  async function stitchImagesWithOverlap(imgParams, totalPixelWidth, totalPixelHeight) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = totalPixelWidth;
    canvas.height = totalPixelHeight;
    ctx.imageSmoothingEnabled = false;

    let currentWriteY = 0;
    
    // Overlap to hide lines
    const overlapPixels = 1; 

    for (let i = 0; i < imgParams.length; i++) {
      const params = imgParams[i];
      const img = await loadImage(params.src);
      
      const drawY = (i === 0) ? 0 : currentWriteY - overlapPixels;

      ctx.drawImage(
        img, 
        params.x, params.y, params.w, params.h, 
        0, drawY, params.w, params.h 
      );
      
      currentWriteY += params.h;
    }

    // --- Filename Prompt ---
    let defaultName = `capture_${Date.now()}.png`;
    let fileName = prompt("Enter filename:", defaultName);

    if (!fileName) fileName = defaultName;
    if (!fileName.toLowerCase().endsWith('.png')) fileName += '.png';

    const a = document.createElement('a');
    a.download = fileName;
    a.href = canvas.toDataURL('image/png');
    a.click();
  }

  function loadImage(src) {
    return new Promise(r => {
        const i = new Image();
        i.onload = () => r(i);
        i.src = src;
    });
  }

  window.addEventListener('keydown', function esc(e) {
    if(e.key === 'Escape') {
        if(overlay.parentNode) overlay.parentNode.removeChild(overlay);
        window.removeEventListener('keydown', esc);
    }
  });

})();