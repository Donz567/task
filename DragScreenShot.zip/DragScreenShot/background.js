chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg.type === 'CAPTURE') {
chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' }, (dataUrl) => {
sendResponse({ image: dataUrl });
});
return true; // async
}
});


chrome.action.onClicked.addListener((tab) => {
chrome.scripting.executeScript({
target: { tabId: tab.id },
files: ['content.js']
});
});