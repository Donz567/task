 document.getElementById('scrapeBtn').addEventListener('click', async () => {
    // 1. Get the current tab
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) return;

    // 2. Try to send the message
    try {
        await chrome.tabs.sendMessage(tab.id, { action: "extract" });
    } catch (error) {
        // 3. If we get the "Receiving end does not exist" error, inject the script manually
        console.log("Script not found. Injecting now...");
        
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"]
        }, () => {
            // 4. Retry sending the message after injection
            if (chrome.runtime.lastError) {
                console.error("Script injection failed: " + chrome.runtime.lastError.message);
            } else {
                chrome.tabs.sendMessage(tab.id, { action: "extract" });
            }
        });
    }
});