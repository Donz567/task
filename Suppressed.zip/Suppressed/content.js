
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "extract") {
            startAutoScroll();
        }
    });
}


async function startAutoScroll() {
    console.log("Starting Auto-Scroll...");

    const banner = document.createElement("div");
    banner.innerText = "Extension is scrolling to load all items... Please wait.";
    banner.style = "position:fixed; top:0; left:0; width:100%; background:orange; color:white; text-align:center; padding:10px; z-index:9999; font-size:16px; font-weight:bold;";
    document.body.appendChild(banner);

    let previousHeight = 0;
    let currentHeight = document.body.scrollHeight;
    let attempts = 0;

    // We use a timer to scroll down repeatedly
    let scrollInterval = setInterval(() => {
        window.scrollTo(0, document.body.scrollHeight);
     
        currentHeight = document.body.scrollHeight;

        if (currentHeight === previousHeight) {
  
            attempts++;
            if (attempts >= 3) {
                
                clearInterval(scrollInterval);
                document.body.removeChild(banner);
                console.log("Scrolling finished. Extracting data...");
                extractAmazonData(); // Trigger the extraction
            }
        } else {
            
            previousHeight = currentHeight;
            attempts = 0;
           
            banner.innerText = `Scrolling... Found more items. (Height: ${currentHeight})`;
        }
    }, 2000); 
}


function extractAmazonData() {
   
    const rows = document.querySelectorAll('div[data-sku]');
    
    if (rows.length === 0) {
        alert("No items found! ensure you are on Seller Central.");
        return;
    }

   
    let csvData = [["SKU", "ASIN", "Title"]]; 

  
    rows.forEach(row => {
        let sku = row.getAttribute('data-sku') || "N/A";

        let titleElement = row.querySelector('div[class*="titleContainer"] a');
        let title = titleElement ? titleElement.innerText.trim() : "N/A";

        let asin = "N/A";
        let spans = Array.from(row.querySelectorAll('span'));
        let asinLabel = spans.find(s => s.innerText.trim() === "ASIN");
        
        if (asinLabel) {
            let asinContainer = asinLabel.closest('div[class*="SplitBox-module__row"]');
            if (asinContainer && asinContainer.children[1]) {
                asin = asinContainer.children[1].innerText.trim();
            }
        } 
        
        if (asin === "N/A" && titleElement) {
             const urlMatch = titleElement.href.match(/\/dp\/([A-Z0-9]{10})/);
             if (urlMatch) asin = urlMatch[1];
        }

        const clean = (text) => text.replace(/(\r\n|\n|\r|,)/gm, " ").trim();
        csvData.push([clean(sku), clean(asin), clean(title)]);
    });

  
    let csvContent = "data:text/csv;charset=utf-8," 
        + csvData.map(e => e.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);

    const dateStr = getSafeRawDateString(); 
    link.setAttribute("download", `Amazon_Suppressed_${dateStr}.csv`);
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}


function getSafeRawDateString() {
    const rawDate = new Date().toString();
    const shortRaw = rawDate.split(" GMT")[0];
    return Date.now();
}

