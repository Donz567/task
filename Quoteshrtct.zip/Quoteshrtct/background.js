chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url.includes("basecamp.com")) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (command) => {
      // Helper to click toolbar buttons
      function clickButton(selector) {
        const btn = document.querySelector(selector);
        if (btn) {
          btn.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
          btn.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
        }
      }

      // Find Basecamp Trix editor
      const editor = document.querySelector("trix-editor[contenteditable]");
      if (!editor || editor.offsetParent === null) {
        // editor.offsetParent === null means it's hidden
        console.warn("⚠️ No active Basecamp editor found, shortcut ignored.");
        return;
      }

      // Make sure it's focused and editable
      editor.focus();
      if (document.activeElement !== editor) {
        console.warn("⚠️ Editor not focused, click inside the comment box first.");
        return;
      }

      
      clickButton('button[data-trix-attribute="quote"]');
      setTimeout(() => {
        clickButton('button[data-trix-attribute="bold"]');
        setTimeout(() => {
          const text =
            command === "status-shortcut" ? "Status: Ongoing" :
            command === "notes-shortcut" ? "Notes: " : "";

          if (text) {
            const sel = window.getSelection();
            if (sel && sel.rangeCount > 0) {
              const range = sel.getRangeAt(0);
              range.deleteContents();
              const strongNode = document.createElement("strong");
              strongNode.textContent = text;
              range.insertNode(strongNode);
              range.setStartAfter(strongNode);
              range.collapse(true);
              sel.removeAllRanges();
              sel.addRange(range);
            }
          }

          console.log(`✅ Quote + Bold active, inserted "${text}"`);
        }, 200);
      }, 100);
    },
    args: [command],
  });
});
