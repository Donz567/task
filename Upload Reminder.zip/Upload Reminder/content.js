(() => {
  const TAG = "[FileChecker]";
  const DEBUG = true;
  const debug = (...args) => DEBUG && console.log(TAG, ...args);

  let modalPromise = null;

  function showConfirmModal(fileName, brands = []) {
  if (modalPromise) return modalPromise;

  modalPromise = new Promise(resolve => {
    const modal = document.createElement("div");
    modal.id = "fileUploadModal";
    Object.assign(modal.style, {
      position: "fixed",
      top: "0",
      left: "0",
      width: "100%",
      height: "100%",
      backgroundColor: "rgba(0,0,0,0.45)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: "2147483647",
      fontFamily: "Arial, sans-serif"
    });

    const box = document.createElement("div");
    Object.assign(box.style, {
      background: "#fff",
      padding: "24px 32px",
      borderRadius: "12px",
      textAlign: "center",
      minWidth: "340px",
      maxWidth: "420px",
      boxShadow: "0 12px 32px rgba(0,0,0,0.25)",
      animation: "fadeIn 0.2s ease-out"
    });

    // Title
    const title = document.createElement("h2");
    title.textContent = "⚠️ Double Check!";
    Object.assign(title.style, {
      margin: "0 0 16px 0",
      fontSize: "18px",
      fontWeight: "bold",
      color: "#333"
    });

    // File name
    const filePara = document.createElement("p");
    filePara.innerHTML = `
      Are you sure you want to upload this file?<br>
      <span style="display:inline-block; margin-top:8px; font-weight:bold; color:#0073bb;">
        ${fileName}
      </span>
    `;

    // Brand info (optional)
    let brandPara = null;
    if (brands.length) {
      brandPara = document.createElement("p");
      brandPara.style.cssText = "margin:12px 0; font-size:14px; color:#555;";
      brandPara.innerHTML = `Detected brand(s): <strong>${brands.join(", ")}</strong>`;
    }

    // Button
    const btn = document.createElement("button");
    btn.id = "fileCheckOk";
    btn.textContent = "Let me check!🧐";
    Object.assign(btn.style, {
      background: "#3234aaff",
      color: "white",
      border: "none",
      outline:"none",
      padding: "10px 20px",
      borderRadius: "6px",
      fontSize: "14px",
      cursor: "pointer",
      transition: "background 0.2s"
    });

    btn.addEventListener("mouseover", () => (btn.style.background = "#5052beff"));
    btn.addEventListener("mouseout", () => (btn.style.background = "#3234aaff"));

    btn.addEventListener("click", () => {
      modal.remove();
      modalPromise = null;
      resolve(true);
    });

    // Assemble modal
    box.appendChild(title);
    box.appendChild(filePara);
    if (brandPara) box.appendChild(brandPara);
    box.appendChild(btn);
    modal.appendChild(box);
    document.body.appendChild(modal);

    btn.focus();
  });

  return modalPromise;
}

  async function extractBrandsFromFile(file) {
    return new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = e => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: "array" });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });

          if (!json.length) return resolve([]);

          // Find Brand column
          const headers = Object.keys(json[0]).map(h => h.toLowerCase().trim());
          const brandKey = Object.keys(json[0]).find(
            k => k.toLowerCase().includes("brand")
          );

          if (!brandKey) {
            resolve([]);
            return;
          }

          const brands = [...new Set(json.map(r => (r[brandKey] || "").toString().trim()).filter(Boolean))];
          resolve(brands);
        } catch (err) {
          console.error(TAG, "❌ Failed to parse file:", err);
          resolve([]);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  }

  function handleFileItem(item) {
  if (item.dataset._filecheckerAdded) return;
  item.dataset._filecheckerAdded = "true";

  const fileName = item.getAttribute("name") || "Unknown File";
  debug("🎯 New kat-file-item detected:", fileName);

  // Find the corresponding <input type="file">
  const host = item.getRootNode().host; // kat-file-upload
  const input = host.shadowRoot.querySelector("input[type=file]");
  const file = input?.files?.[0];

  if (!file) {
    debug("⚠️ No file object found, just showing basic modal");
    showConfirmModal(fileName);
    return;
  }

  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

      // Look for Brand or Brand Name column
      const brands = new Set();
      rows.forEach(r => {
        if (r["Brand"]) brands.add(r["Brand"]);
        if (r["Brand Name"]) brands.add(r["Brand Name"]);
      });

      const brandList = Array.from(brands).slice(0, 5); // first few only
      debug("📦 Detected brands:", brandList);

      showConfirmModal(fileName, brandList);
    } catch (err) {
      console.error("❌ Failed to parse Excel:", err);
      showConfirmModal(fileName, []);
    }
  };
  reader.readAsArrayBuffer(file);
}


  function observeShadow(root, inputEl) {
    debug("🔍 Observing inside shadow root:", root);

    const observer = new MutationObserver(mutations => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType !== 1) continue;

          if (node.tagName?.toLowerCase() === "kat-file-item") {
            handleFileItem(node, inputEl);
          }

          const items = node.querySelectorAll?.("kat-file-item") || [];
          items.forEach(n => handleFileItem(n, inputEl));
        }
      }
    });

    observer.observe(root, { childList: true, subtree: true });
  }

  function init() {
    debug("🚀 FileChecker init");

    const hosts = document.querySelectorAll("kat-file-upload");
    if (!hosts.length) {
      debug("❌ kat-file-upload not found yet, retrying...");
      setTimeout(init, 500);
      return;
    }

    hosts.forEach(host => {
      const shadow = host.shadowRoot;
      if (!shadow) {
        debug("❌ No shadowRoot yet, retrying...");
        setTimeout(init, 500);
        return;
      }

      const uploadRoot = shadow.querySelector(".file-upload");
      const inputEl = shadow.querySelector("input[type=file]");
      if (!uploadRoot || !inputEl) {
        debug("❌ upload root/input not found, retrying...");
        setTimeout(init, 500);
        return;
      }

      observeShadow(uploadRoot, inputEl);
      debug("✅ Observer attached inside kat-file-upload shadowRoot");
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
